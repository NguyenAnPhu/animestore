<?php 
     include "./PHPMailer/src/PHPMailer.php";
     include "./PHPMailer/src/Exception.php";
     include "./PHPMailer/src/OAuth.php";
     include "./PHPMailer/src/POP3.php";
     include "./PHPMailer/src/SMTP.php";

     use PHPMailer\PHPMailer\PHPMailer;
     use PHPMailer\PHPMailer\Exception;
     $mail = new PHPMailer(true); 
     print_r($mail);
?>